# DEVA Portfolio Website

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser (Chrome, Edge, or Firefox).
3. To get the most reliable local file storage behavior, run it through a local web server:
   - If Python is installed, open a terminal in this folder and run: `python -m http.server 8000`
   - Visit `http://localhost:8000`

## Add your work
- Open the Work section.
- Click **Add Your Work** and provide a title, category, description, and files; or drag videos/images onto the drop area.
- Supported media types are browser-readable video and image files. File size is limited to 500 MB per file, subject to available browser storage.
- Projects are saved in IndexedDB in the same browser and device.

## Important storage / publishing note
This version is fully interactive on the client side, but it does **not** upload files to a server. Local uploads are not visible to clients visiting your public website or to you on another device. For public, cross-device work storage, connect a backend or cloud storage service (for example Supabase Storage, Firebase Storage, or your own server), configure access rules, and deploy the website on HTTPS hosting.

## Contact details
The contact call-to-action uses the supplied number `+25107049640`. Verify the exact international dialing format and replace it in the WhatsApp link if needed. The email button opens the visitor's default email app without assuming an unverified email address.

## Customize
- Change text and service cards directly in `index.html`.
- Update colors in the `:root` CSS variables near the top.
- Replace the simple hero portrait placeholder with your own licensed portrait image by changing the `.portrait` element to an `<img>` element.
- Replace placeholder social links with your real profile URLs.
